/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "makedrink.h"
#include "driver_uart.h"  // ����UART1_SendData����
#include <string.h>       // ����strlen��strncmp����
#include "stm32f1xx_hal.h" // ����System_Reset����
#include <stdio.h>
#include <ctype.h> // ����ctype.hͷ�ļ���ʹ��isalnum����
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
//typedef enum {
//    STATE_IDLE,
//    STATE_SOLID,
//    STATE_LIQUID,
//    STATE_GAS,
//    STATE_FINISH
//} SystemState;

//SystemState g_current_state = STATE_IDLE;

typedef struct {
    uint8_t data[RX_BUFFER_SIZE];
    uint16_t length;
    uint32_t timestamp;
} UART_RxEventData;

osMessageQueueId_t rxEventQueue;
const osMessageQueueAttr_t rxEventQueue_attributes = {
    .name = "rxEventQueue"
};
/* USER CODE END Variables */
/* Definitions for controltask */
osThreadId_t controltaskHandle;
const osThreadAttr_t controltask_attributes = {
  .name = "controltask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal2,
};
/* Definitions for receivetask */
osThreadId_t receivetaskHandle;
const osThreadAttr_t receivetask_attributes = {
  .name = "receivetask",
  .stack_size = 256 * 4,  // ����ջ��С
  .priority = (osPriority_t) osPriorityHigh,  // ������ȼ�
};
/* Definitions for cmdQueue */
osMessageQueueId_t cmdQueueHandle;
const osMessageQueueAttr_t cmdQueue_attributes = {
  .name = "cmdQueue"
};
/* Definitions for xControlSemaphore */
osSemaphoreId_t xControlSemaphoreHandle;
const osSemaphoreAttr_t xControlSemaphore_attributes = {
  .name = "xControlSemaphore"
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void control_task(void *argument);
void receive_task(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* Create the semaphores(s) */
  /* creation of xControlSemaphore */
  xControlSemaphoreHandle = osSemaphoreNew(1, 0, &xControlSemaphore_attributes);

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* creation of cmdQueue */
   cmdQueueHandle = osMessageQueueNew(32, sizeof(uint8_t*), &cmdQueue_attributes);
 
  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  // rxEventQueue = osMessageQueueNew(10, sizeof(UART_RxEventData), &rxEventQueue_attributes);
  
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of controltask */
  controltaskHandle = osThreadNew(control_task, NULL, &controltask_attributes);

  /* creation of receivetask */
  receivetaskHandle = osThreadNew(receive_task, NULL, &receivetask_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_control_task */

void control_task(void *argument)
{
  /* USER CODE BEGIN control_task */
 
  
  // ���������ӳ�ȷ��ϵͳ�ȶ�
  osDelay(1000);


//  make_coffee();
//     
//    
//	vTaskSuspend(NULL);
  /* Infinite loop */
  for(;;) {
//    
      // �ȴ��ź���֪ͨ��ʼ����
        if (osSemaphoreAcquire(xControlSemaphoreHandle, osWaitForever) == osOK) {
            // ִ���ĸ����裬��ͨ�����ڷ���ִ�н���
            UART1_SendData((uint8_t *)"STEP_ICE\n", strlen("STEP_ICE\n"));
            add_ice();  // ���ӱ���
            osDelay(1000);
            UART1_SendData((uint8_t *)"STEP_SOLID\n", strlen("STEP_SOLID\n"));
            add_solid();// ���ӹ�����
            osDelay(1000);

            UART1_SendData((uint8_t *)"STEP_LIQUID\n", strlen("STEP_LIQUID\n"));
            add_liquid(); // ����Һ����
            osDelay(1000);

            UART1_SendData((uint8_t *)"STEP_STIR\n", strlen("STEP_STIR\n"));
              stir(); // ����
            osDelay(1000);

            UART1_SendData((uint8_t *)"STEP_DONE\n", strlen("STEP_DONE\n"));
        }
  }
  /* USER CODE END control_task */
}

/* USER CODE BEGIN Header_receive_task */
/**
* @brief Function implementing the receivetask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_receive_task */
void receive_task(void *argument)
{
  /* USER CODE BEGIN receive_task */
  /* Infinite loop */



  
  for(;;)
  {
       uint8_t *recv_data;

        // ����Ϣ������ȡ�����ڽ��յ�����
        if (osMessageQueueGet(cmdQueueHandle, &recv_data, NULL, osWaitForever) == osOK) {
            printf("�յ�����: %s\r\n", recv_data);

            // ��ѡ����У������ȵ�

            // �� recv_data ���� control_task�������ֱ��ʹ���ź�������һ�����У�
            // �������ź�����ʽ֪ͨ
            osSemaphoreRelease(xControlSemaphoreHandle);

            // �ͷŶ�̬������ڴ�
            vPortFree(recv_data);
  }
  /* USER CODE END receive_task */
}


/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

}